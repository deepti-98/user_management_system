-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 01, 2023 at 03:23 AM
-- Server version: 10.5.18-MariaDB
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `winserver_dmb`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `dob` varchar(100) DEFAULT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `signature` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `password`, `name`, `role`, `mobile`, `email`, `address`, `gender`, `dob`, `picture`, `signature`) VALUES
(1, 'abc123', 'Deeptimala Behera', 'super_admin', '1234567890', 'superadmin@gmail.com', 'Khandagiri, Bhubaneswar', 'female', '1990-01-01', 'profile.jpg', 'signature.png'),
(2, 'xyz789', 'Sweetie Sahoo', 'admin', '9348779686', 'admin1@gmail.com', 'Pahala, Khandagiri', 'female', '1998-03-05', '9b5f6b715f6a48eb718e504f5274497b.jpg', '4e780273aad4ec81e3c9dadc474b6f9a.png'),
(3, 'uvw456', 'Kunu Sahoo', 'admin', '012345678', 'admin2@gmail.com', 'Rasulgarh, Bhubaneswar', 'female', '2023-09-14', 'f07a67c2572f02e1376dfbb8f0c97ab0.jpg', 'dd4c849078f4b9ab9d55161a6634d9ea.png'),
(4, '111111', 'User One', 'user', '8658534958', 'user1@gmail.com', 'Kolathia, Bhubaneswar', 'male', '1990-01-05', '655760890ada5662fec0cb4b5e19e9a7.jpg', 'f4a45b8c7544e663a5f80810e85d20fe.png'),
(17, '222222', 'User Two', 'user', '0123456789', 'user2@gmail.com', 'Vanivihar, Bhubaneswar', 'male', '', 'e81753568fced01f64b89102d63cf7e7.jpg', '4b23b9fb5d617c1a4e4573987420340a.png'),
(18, '333333', 'User Three', 'user', '0123456789', 'user3@gmail.com', 'Acharya Vihar, Bhubaneswar', 'male', '', '14f0082effac0f57a2482a6057f54830.jpg', '9a93ec03096d141e52b57e12ba3be7bb.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
